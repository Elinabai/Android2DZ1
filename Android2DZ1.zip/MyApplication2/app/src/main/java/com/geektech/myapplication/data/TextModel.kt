package com.geektech.myapplication.data

class TextModel(
    val image: String,
    val name: String ,

    )